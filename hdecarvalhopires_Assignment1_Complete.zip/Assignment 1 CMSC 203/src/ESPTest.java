import java.util.Scanner;

public class ESPTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome! Let's test your ESP."); 
        System.out.print("Enter your name: ");

		
        String name = scanner.nextLine(); 
 

        System.out.print("Describe yourself: ");
        String description = scanner.nextLine();

        System.out.print("Due Date: ");
        String dueDate = scanner.nextLine();

        System.out.println(name);
        System.out.println(description);
        System.out.println("Due Date: " + dueDate);

        System.out.println("CMSC203 Assignment1: Test your ESP skills!");

        int correctGuesses = 0;
        final String COLOR_RED = "Red";
        final String COLOR_GREEN = "Green";
        final String COLOR_BLUE = "Blue";
        final String COLOR_ORANGE = "Orange";
        final String COLOR_YELLOW = "Yellow";

        for (int round = 1; round <= 11; round++) {
            System.out.println("Round " + round);
            System.out.println("I am thinking of a color.");
            System.out.println("Is it Red, Green, Blue, Orange, or Yellow?");
            System.out.print("Enter your guess: ");
            String userGuess = scanner.nextLine();

            int randomNumber = (int) (Math.random() * 5); // Generates a random number between 0 and 4

            switch (randomNumber) {
                case 0:
                    System.out.println("I was thinking of " + COLOR_RED);
                    break;
                case 1:
                    System.out.println("I was thinking of " + COLOR_GREEN);
                    break;
                case 2:
                    System.out.println("I was thinking of " + COLOR_BLUE);
                    break;
                case 3:
                    System.out.println("I was thinking of " + COLOR_ORANGE);
                    break;
                case 4:
                    System.out.println("I was thinking of " + COLOR_YELLOW);
                    break;
            }

            if (userGuess.equalsIgnoreCase(COLOR_RED)
                    || userGuess.equalsIgnoreCase(COLOR_GREEN)
                    || userGuess.equalsIgnoreCase(COLOR_BLUE)
                    || userGuess.equalsIgnoreCase(COLOR_ORANGE)
                    || userGuess.equalsIgnoreCase(COLOR_YELLOW)) {
                if (userGuess.equalsIgnoreCase(COLOR_RED) && randomNumber == 0
                        || userGuess.equalsIgnoreCase(COLOR_GREEN) && randomNumber == 1
                        || userGuess.equalsIgnoreCase(COLOR_BLUE) && randomNumber == 2
                        || userGuess.equalsIgnoreCase(COLOR_ORANGE) && randomNumber == 3
                        || userGuess.equalsIgnoreCase(COLOR_YELLOW) && randomNumber == 4) {
                    System.out.println("Hooray! That was correct!");
                    correctGuesses++;
                } else {
                    System.out.println("Sorry! That is incorrect.");
                }
            } else {
                System.out.println("You entered an incorrect color.");
                while (true) {
                    System.out.println("Is it Red, Green, Blue, Orange, or Yellow?");
                    System.out.print("That's ok! Try again: ");
                    userGuess = scanner.nextLine();
                    if (userGuess.equalsIgnoreCase(COLOR_RED)
                            || userGuess.equalsIgnoreCase(COLOR_GREEN)
                            || userGuess.equalsIgnoreCase(COLOR_BLUE)
                            || userGuess.equalsIgnoreCase(COLOR_ORANGE)
                            || userGuess.equalsIgnoreCase(COLOR_YELLOW)) {
                        if (userGuess.equalsIgnoreCase(COLOR_RED) && randomNumber == 0
                                || userGuess.equalsIgnoreCase(COLOR_GREEN) && randomNumber == 1
                                || userGuess.equalsIgnoreCase(COLOR_BLUE) && randomNumber == 2
                                || userGuess.equalsIgnoreCase(COLOR_ORANGE) && randomNumber == 3
                                || userGuess.equalsIgnoreCase(COLOR_YELLOW) && randomNumber == 4) {
                            System.out.println("Hooray! That was correct!");
                            correctGuesses++;
                        } else {
                            System.out.println("Sorry! That is incorrect.");
                        }
                        break;
                    } else {
                        System.out.println("You entered an incorrect color.");
                    }
                }
            }
        }

        System.out.println("Game Over");
        System.out.println("You guessed " + correctGuesses + " out of 11 colors correctly.");
        System.out.println("Student Name: " + name);
        System.out.println("User Description: " + description);
        System.out.println("Due Date: " + dueDate);

        scanner.close();
    }
}
